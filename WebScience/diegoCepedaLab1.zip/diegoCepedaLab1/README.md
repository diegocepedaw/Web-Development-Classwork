Diego Cepeda 

Initially I was emploting the getJSON function but it was creating issues where the rest of my script would have trouble interacting with the data fetched from that unction
to fix this I used the ajax function. 

At first I was going to use fadeIn and FadeOut but I decided that the slide would make for a cleaner looking interface with less overhead.

Another complication was the lack of a good built in jquery wait that would allow me to time my actions so I had to make one myself.

