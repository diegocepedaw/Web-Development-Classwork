Diego Cepeda

Some of the challenges I faced were interfacing with the api, I chose to use openweathermap. Additionally the scroll with multiple things per row was kind of tricky. 
Lastly having the thermometer update gave me a bit of trouble since it used webkit fades and I was trying to update that as a background color and not a background image.
