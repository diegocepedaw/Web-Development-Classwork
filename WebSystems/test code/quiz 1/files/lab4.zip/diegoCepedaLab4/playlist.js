{
    "playlist": [
        {
            "title": "Blue Orchid",
            "artist": "White Stripes",
            "album": "Get Behind Me Satan",
            "release": "2005",
            "genre": "Garage Rock",
            "website": "www.whitestripes.com",
            "cover": "http://d3mjk82f332v2.cloudfront.net/assets/NewsPhotos/GBMSlenticular2.gif"
        },
        {
            "title": "Hello Operator",
            "artist": "White Stripes",
            "album": "De Stijl",
            "release": "2005",
            "genre": "Garage Rock",
            "website": "www.whitestripes.com",
            "cover": "http://images.rapgenius.com/379b1eff320adfb02f964ac0c8f7ad88.500x500x1.jpg"
        },
        {
            "title": "Icky Thump",
            "artist": "White Stripes",
            "album": "Icky Thump",
            "release": "207",
            "genre": "Garage Rock",
            "website": "www.whitestripes.com",
            "cover": "http://ecx.images-amazon.com/images/I/61Fuvh7ULcL.jpg"
        },
        {
            "title": "Fell in Love with a Girl",
            "artist": "White Stripes",
            "album": "White Blood Cells",
            "release": "2001",
            "genre": "Garage Rock",
            "website": "www.whitestripes.com",
            "cover": "https://upload.wikimedia.org/wikipedia/en/1/12/The_White_Stripes_-_White_Blood_Cells.jpg"
        }
    ]
}